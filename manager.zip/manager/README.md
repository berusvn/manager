# Manager
Manager is Filesystem management, integrated mysql database management. Use on your website directly.
## Author
- **Izero**

## Usage
- Just upload to your website
- Unzip manager.zip
- Run `yourdomain.com/manager`
- Login with default 
  - Username: `admin`
  - Password: `12345`
- You can change your info in settings
